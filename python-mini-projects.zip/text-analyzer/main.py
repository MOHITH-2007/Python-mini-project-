import re, sys
from collections import Counter

def analyze(text):
    words = re.findall(r"[a-zA-Z']+", text.lower())
    return {
        "characters": len(text),
        "words": len(words),
        "sentences": len(re.findall(r"[.!?]+", text)),
        "unique_words": len(set(words)),
        "top_words": Counter(w for w in words if len(w) > 3).most_common(5),
    }

if __name__ == "__main__":
    text = open(sys.argv[1], encoding="utf-8").read() if len(sys.argv) > 1 else input("Enter text: ")
    for k, v in analyze(text).items():
        print(f"{k}: {v}")
