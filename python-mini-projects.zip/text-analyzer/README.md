# Text Analyzer
Counts characters, words, sentences and most frequent words in text or a file.
**Tech:** Python (`re`, `collections`) | **Run:** `python main.py sample.txt`
