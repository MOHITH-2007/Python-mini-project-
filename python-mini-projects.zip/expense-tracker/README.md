# Expense Tracker
CLI app to record and summarise daily expenses using SQLite.
**Tech:** Python, SQLite3 | **Run:** `python main.py`
## Features
- Add, view, delete expenses
- Category-wise totals
