import sqlite3
from datetime import date

conn = sqlite3.connect("expenses.db")
conn.execute("""CREATE TABLE IF NOT EXISTS expenses(
    id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT, category TEXT, amount REAL, note TEXT)""")

def add():
    cat = input("Category: ")
    amt = float(input("Amount: "))
    note = input("Note: ")
    conn.execute("INSERT INTO expenses(day,category,amount,note) VALUES(?,?,?,?)",
                 (str(date.today()), cat, amt, note))
    conn.commit()
    print("Added.")

def view():
    for r in conn.execute("SELECT id, day, category, amount, note FROM expenses ORDER BY id DESC"):
        print(r)

def summary():
    for cat, total in conn.execute("SELECT category, SUM(amount) FROM expenses GROUP BY category"):
        print(f"{cat:<15} ₹{total:.2f}")
    print("Total: ₹%.2f" % (conn.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]))

def delete():
    conn.execute("DELETE FROM expenses WHERE id=?", (int(input("ID: ")),))
    conn.commit()

actions = {"1": add, "2": view, "3": summary, "4": delete}
while True:
    c = input("\n1) Add 2) View 3) Summary 4) Delete 5) Exit: ").strip()
    if c == "5":
        break
    actions.get(c, lambda: print("Invalid"))()
