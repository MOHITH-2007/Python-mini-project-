# Quiz Game
Multiple-choice quiz loaded from a JSON file. Add your own questions in `questions.json`.
**Tech:** Python (`json`, `random`) | **Run:** `python main.py`
