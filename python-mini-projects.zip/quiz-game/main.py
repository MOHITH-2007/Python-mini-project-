import json, random

with open("questions.json", encoding="utf-8") as f:
    questions = json.load(f)
random.shuffle(questions)
score = 0
for i, q in enumerate(questions, 1):
    print(f"\nQ{i}. {q['q']}")
    for n, opt in enumerate(q["options"], 1):
        print(f"  {n}. {opt}")
    try:
        ans = int(input("Your answer: "))
    except ValueError:
        ans = 0
    if ans == q["answer"]:
        print("Correct!")
        score += 1
    else:
        print("Wrong. Answer:", q["options"][q["answer"] - 1])
print(f"\nScore: {score}/{len(questions)} ({score/len(questions)*100:.0f}%)")
