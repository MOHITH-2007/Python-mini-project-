import secrets, string, re

def generate(length=12, symbols=True):
    chars = string.ascii_letters + string.digits + (string.punctuation if symbols else "")
    return "".join(secrets.choice(chars) for _ in range(length))

def strength(pw):
    score = sum([len(pw) >= 8, len(pw) >= 12, bool(re.search(r"[a-z]", pw)),
                 bool(re.search(r"[A-Z]", pw)), bool(re.search(r"\d", pw)),
                 bool(re.search(r"\W", pw))])
    return ["Very Weak", "Very Weak", "Weak", "Fair", "Good", "Strong", "Very Strong"][score]

if __name__ == "__main__":
    while True:
        c = input("\n1) Generate  2) Check strength  3) Exit: ").strip()
        if c == "1":
            n = int(input("Length: "))
            pw = generate(n)
            print("Password:", pw, "|", strength(pw))
        elif c == "2":
            print("Strength:", strength(input("Password: ")))
        elif c == "3":
            break
