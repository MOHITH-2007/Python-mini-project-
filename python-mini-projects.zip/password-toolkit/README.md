# Password Toolkit
A CLI tool to generate secure random passwords and rate password strength.
**Tech:** Python (`secrets`, `re`) | **Run:** `python main.py`
## Features
- Cryptographically secure generation
- Strength rating (length, case, digits, symbols)
