# Python Mini Projects
By Mohith Kumar K

| Project | Concepts |
|---|---|
| password-toolkit | secrets, regex, CLI |
| expense-tracker | SQLite, CRUD |
| quiz-game | JSON, file handling |
| file-organizer | pathlib, shutil |
| text-analyzer | regex, Counter |

Each folder has its own README. Run with `python main.py`.
