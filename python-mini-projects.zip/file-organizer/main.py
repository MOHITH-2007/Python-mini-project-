import shutil, sys
from pathlib import Path

CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".webp"},
    "Documents": {".pdf", ".docx", ".txt", ".pptx", ".xlsx", ".csv"},
    "Videos": {".mp4", ".mkv", ".mov"},
    "Audio": {".mp3", ".wav"},
    "Archives": {".zip", ".rar", ".7z"},
    "Code": {".py", ".java", ".js", ".html", ".css", ".json"},
}

def category(ext):
    return next((k for k, v in CATEGORIES.items() if ext.lower() in v), "Others")

def organize(folder, dry_run=True):
    for f in Path(folder).iterdir():
        if f.is_file():
            dest = Path(folder) / category(f.suffix)
            print(f"{f.name} -> {dest.name}/")
            if not dry_run:
                dest.mkdir(exist_ok=True)
                shutil.move(str(f), str(dest / f.name))

if __name__ == "__main__":
    folder = sys.argv[1] if len(sys.argv) > 1 else "."
    organize(folder, dry_run="--apply" not in sys.argv)
