# File Organizer
Sorts files in a folder into subfolders by type.
**Tech:** Python (`pathlib`, `shutil`)
**Preview:** `python main.py <folder>`  |  **Apply:** `python main.py <folder> --apply`
